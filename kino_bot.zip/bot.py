import logging
import json
import os
import asyncio
from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
)

BOT_TOKEN = "7563957099:AAEfou1Rs72mlyNp5QznZtFyPxP4UT6selg"
CHANNEL_USERNAME = "@piimaenglish_edu"
ADMIN_IDS = [961863682]
DATA_FILE = "movies.json"

logging.basicConfig(level=logging.INFO)

if not os.path.exists(DATA_FILE):
    with open(DATA_FILE, "w") as f:
        json.dump({"movies": {}, "last_id": 0}, f)

def check_subscription(user_id, context: ContextTypes.DEFAULT_TYPE):
    try:
        member = context.bot.get_chat_member(CHANNEL_USERNAME, user_id)
        return member.status in ['member', 'administrator', 'creator']
    except:
        return False

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    update.message.reply_text(
        "👋 Salom!\n📥 Kino yuborish uchun faylni hujjat sifatida yuboring (faqat admin).\n🔎 Kino ko‘rish uchun raqamini yuboring."
    )

async def add_movie(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in ADMIN_IDS:
        await update.message.reply_text("⛔️ Sizda ruxsat yo‘q.")
        return

    if not update.message.document:
        await update.message.reply_text("⛔️ Iltimos, kino faylini hujjat sifatida yuboring.")
        return

    with open(DATA_FILE, "r") as f:
        data = json.load(f)

    data["last_id"] += 1
    movie_id = str(data["last_id"])
    file_id = update.message.document.file_id

    data["movies"][movie_id] = {
        "file_id": file_id,
        "views": 0
    }

    with open(DATA_FILE, "w") as f:
        json.dump(data, f)

    await update.message.reply_text(f"✅ Kino qo‘shildi! Raqami: {movie_id}")

async def send_movie(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if check_subscription(update.effective_user.id, context):
        await update.message.reply_text("🔐 Iltimos, avval kanalga a’zo bo‘ling: " + CHANNEL_USERNAME)
        return

    movie_id = update.message.text.strip()
    if not movie_id.isdigit():
        await update.message.reply_text("🔢 Kino raqamini kiriting.")
        return

    with open(DATA_FILE, "r") as f:
        data = json.load(f)

    movie = data["movies"].get(movie_id)
    if not movie:
        await update.message.reply_text("❌ Kino topilmadi.")
        return

    movie["views"] += 1
    with open(DATA_FILE, "w") as f:
        json.dump(data, f)

    await update.message.reply_document(
        movie["file_id"],
        caption=f"Kino raqami: {movie_id}\n📊 Ko‘rishlar: {movie['views']}"
    )

async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in ADMIN_IDS:
        await update.message.reply_text("⛔️ Sizda ruxsat yo‘q.")
        return

    with open(DATA_FILE, "r") as f:
        data = json.load(f)

    stats_text = "📊 Statistikalar:\n"
    for movie_id, movie in data["movies"].items():
        stats_text += f"🎬 {movie_id}: {movie['views']} ta ko‘rish\n"

    await update.message.reply_text(stats_text or "Statistika yo‘q.")

def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("stats", stats))
    app.add_handler(MessageHandler(filters.Document.ALL, add_movie))
    app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), send_movie))

    print("✅ Bot ishga tushdi.")
    app.run_polling()  # asyncio.run emas!

if __name__ == "__main__":
    main()