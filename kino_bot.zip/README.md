# Kino Bot
Simple Telegram bot to share movie files only with channel members.